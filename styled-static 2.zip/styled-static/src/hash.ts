/**
 * Murmurhash2 implementation for generating short, deterministic hashes.
 * Used to create unique class names from CSS content.
 *
 * Based on https://github.com/garycourt/murmurhash-js
 * This is a well-known, fast, non-cryptographic hash function.
 */
export function hash(str = ""): string {
  let l = str.length;
  let h = l ^ l;
  let i = 0;
  let k: number;

  while (l >= 4) {
    k =
      (str.charCodeAt(i) & 0xff) |
      ((str.charCodeAt(++i) & 0xff) << 8) |
      ((str.charCodeAt(++i) & 0xff) << 16) |
      ((str.charCodeAt(++i) & 0xff) << 24);

    k =
      (k & 0xffff) * 0x5bd1e995 + ((((k >>> 16) * 0x5bd1e995) & 0xffff) << 16);
    k ^= k >>> 24;
    k =
      (k & 0xffff) * 0x5bd1e995 + ((((k >>> 16) * 0x5bd1e995) & 0xffff) << 16);

    h =
      ((h & 0xffff) * 0x5bd1e995 +
        ((((h >>> 16) * 0x5bd1e995) & 0xffff) << 16)) ^
      k;

    l -= 4;
    ++i;
  }

  // Handle remaining bytes (1-3) without switch fallthrough
  if (l >= 3) h ^= (str.charCodeAt(i + 2) & 0xff) << 16;
  if (l >= 2) h ^= (str.charCodeAt(i + 1) & 0xff) << 8;
  if (l >= 1) {
    h ^= str.charCodeAt(i) & 0xff;
    h =
      (h & 0xffff) * 0x5bd1e995 + ((((h >>> 16) * 0x5bd1e995) & 0xffff) << 16);
  }

  h ^= h >>> 13;
  h = (h & 0xffff) * 0x5bd1e995 + ((((h >>> 16) * 0x5bd1e995) & 0xffff) << 16);
  h ^= h >>> 15;

  return (h >>> 0).toString(36);
}
